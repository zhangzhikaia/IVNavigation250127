﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.



#include "SNavigationEditor.h"

#if SWITCH_WITH_EDITOR

#include "IAssetViewport.h"
#include "InteractiveNavigationSettings.h"
#include "LevelEditor.h"


void SNavigationEditor::Construct(const FArguments& InArgs)
{
	AutoGetDPIScaling();
	
	if(!OnPostEditChangePropertyAutoGetDPIScaling.IsValid())
	{
		OnPostEditChangePropertyAutoGetDPIScaling = FNavigationSettingsDelegates::OnPostEditChangeProperty.AddRaw(this,&SNavigationEditor::AutoGetDPIScaling);
	}
	
	EditorViewportClient = &FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetFirstActiveViewport()->GetAssetViewportClient();
	
	CreateNavigationElements();
}

FVector2D SNavigationEditor::ComputeDesiredSize(float X) const
{
	return DesiredSize;
}

void SNavigationEditor::UpdateViewRotation() const
{
	if(EditorViewportClient == nullptr) return;
	
	static ELevelViewportType LastTimeLevelViewportType = LVT_None;
	const ELevelViewportType CurrentViewportType = EditorViewportClient->GetViewportType();
	//static FRotator LastFixRotator = FRotator::ZeroRotator;
	
	ViewStateIsInChanging = true;
	//在type不变的前提下, 考虑所有不需要更新旋转的情况, 改变type当帧更新
	if(LastTimeLevelViewportType == CurrentViewportType)
	{
		//当前不是透视视图, 旋转不更新 
		if(CurrentViewportType != LVT_Perspective)
		{
			ViewStateIsInChanging = false;
		}
		//当前并非需要修复旋转, 旋转值等于已记录的, 不需要更新旋转, 该判断的消耗比更新旋转更大, 但涉及到更新排序(排序消耗并不高), 故判断
		else if(!UpdateNavigationNeedFixState() && ViewRotation.Equals(EditorViewportClient->GetViewRotation()))
		{
			ViewStateIsInChanging = false;
		}
		//在修复旋转以及未按下LeftMouseButton时, 旋转一定是不变的, 不需要再判断旋转值. 无论旋转值保持为alt之前的, 还是进入之后修复, 都会是正确的
		else if(UpdateNavigationNeedFixState() && !EditorViewportClient->Viewport->KeyState(EKeys::LeftMouseButton))
		{
			ViewStateIsInChanging = false;
		}
	}
	
	if(ViewStateIsInChanging)
	{
		//透视视图情况
		if(CurrentViewportType == LVT_Perspective)
		{
			ViewRotation = EditorViewportClient->GetViewRotation();
			
			if(UpdateNavigationNeedFixState())
			{
				ViewRotation.Yaw *= -1.f;
				ViewRotation.Yaw += 90.f;
			}
		}     

		//正交视图情况
		else if(CurrentViewportType == LVT_OrthoXY)         ViewRotation = LookFromZ;      //Top
		else if(CurrentViewportType == LVT_OrthoNegativeXY) ViewRotation = LookToZ;        //Bottom
		else if(CurrentViewportType == LVT_OrthoNegativeXZ) ViewRotation = LookToY;        //Left
		else if(CurrentViewportType == LVT_OrthoXZ)         ViewRotation = LookFromY;      //Right
		else if(CurrentViewportType == LVT_OrthoNegativeYZ) ViewRotation = LookFromX;      //Front
		else if(CurrentViewportType == LVT_OrthoYZ)         ViewRotation = LookToX;        //Back
		
		LastTimeLevelViewportType = CurrentViewportType;
	}
}

void SNavigationEditor::AutoGetDPIScaling()
{
	//Editor的Widget缩放，只受windows设置影响，在设置不变的情况下啊，无论窗口如何缩放,项目设置如何设置缩放，都不改变编辑器Widget缩放
	const UInteractiveNavigationSettings* Settings = GetDefault<UInteractiveNavigationSettings>();
	//自动获取
	if(Settings->bManualCorrectDeviation == false)
	{
		//只在初始化时设置该缩放倍数, 因为用户几乎不可能在使用引擎途中调整系统DPI,即使调整,重新构造即可. 若要实时判断, 性能消耗浪费
		FDisplayMetrics DisplayMetrics;
		FDisplayMetrics::RebuildDisplayMetrics(DisplayMetrics);

		TArray<FMonitorInfo>& MonitorInfoArray = DisplayMetrics.MonitorInfo;
		if(MonitorInfoArray.Num() == 0) return;
		//只获取屏幕0的DPI, 因为用户几乎不可能设置两块屏幕为不同的DPI, 尽管有这种可能性
		
		ScaleBasedDPI = (float)MonitorInfoArray[0].DPI / 96.f;
	}
	//手动设置
	else
	{
		switch (Settings->DPI)
		{
		case EDisplayDeviceScaling::DPI_100: ScaleBasedDPI = 1.f;
			break;
		case EDisplayDeviceScaling::DPI_125: ScaleBasedDPI = 1.25f;
			break;
		case EDisplayDeviceScaling::DPI_150: ScaleBasedDPI = 1.5f;
			break;
		case EDisplayDeviceScaling::DPI_175: ScaleBasedDPI = 1.75f;
			break;
		case EDisplayDeviceScaling::DPI_200: ScaleBasedDPI = 2.f;
			break;
		}
	}
	
	UpdateOffsetValue();
}

bool SNavigationEditor::UpdateNavigationNeedFixState() const
{
	static bool bNeedFix = false;

	const FViewport* ClientViewport = EditorViewportClient->Viewport;
	
	const bool bMouseButtonDown =
		ClientViewport->KeyState(EKeys::LeftMouseButton) ||
		ClientViewport->KeyState(EKeys::RightMouseButton)||
		ClientViewport->KeyState(EKeys::MiddleMouseButton);
	
	const bool bAltPressed = EditorViewportClient->IsAltPressed();

	//代替记录鼠标移动, 记录鼠标移动不够灵敏, 最小为1像素单位, 容易延迟
	const bool bCameraMoving = EditorViewportClient->IsMovingCamera();
	
	//三者并列时, 需要修复
	if(bCameraMoving && bMouseButtonDown && bAltPressed)
	{
		bNeedFix = true;
	}

	//仅在松开alt时, 复原
	if(bNeedFix == true)
	{
		if(bAltPressed == false)
		{
			bNeedFix = false;
		}
	}
	
	return bNeedFix;
}


#endif



