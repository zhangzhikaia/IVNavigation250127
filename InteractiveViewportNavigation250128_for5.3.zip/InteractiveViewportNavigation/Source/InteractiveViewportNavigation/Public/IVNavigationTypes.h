﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

UENUM(BlueprintType)
enum class ENavigationPart : uint8
{
	Default UMETA(DisplayName="Empty"),
	
	PositiveX UMETA(DisplayName="X"),
	PositiveY UMETA(DisplayName="Y"),
	PositiveZ UMETA(DisplayName="Z"),
	NegativeX UMETA(DisplayName="-X"),
	NegativeY UMETA(DisplayName="-Y"),
	NegativeZ UMETA(DisplayName="-Z"),
};
