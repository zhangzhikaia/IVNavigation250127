﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "InputState.h"
#include "IVNavigationTypes.h"
#include "Widgets/SOverlay.h"
#include "Styling/CoreStyle.h"
//#include "EditorGizmos/TransformGizmo.h"

class UInteractiveNavigationSettings;
class SDirectionIndicatorWidget;


class SNavigationManager : public SOverlay
{
	
public:
	//轴颜色
	static constexpr FColor DIAxisColorX = FColor(200, 46, 74);
	static constexpr FColor DIAxisColorY = FColor(113, 160, 22);
	static constexpr FColor DIAxisColorZ = FColor(44, 141, 254);
	
	static constexpr uint8 ElementsNum = 6;
	static constexpr float AxisLength = 32.f;
		

	
	inline static const FVector2f OffsetToCenter = FVector2f(AxisLength*2);
	inline static const FVector2D DesiredSize = FVector2D(OffsetToCenter*2);
	
	inline static const FSlateFontInfo SlateFontInfo = FCoreStyle::Get().GetFontStyle(FName("EmbossedText"));
	inline static const FVector2f TextOffset = FVector2f(-4.f,-6.5f);
	inline static const FVector2f TextOffset_ = FVector2f(-7.f,-7.5f);



	// T InPitch, T InYaw, T InRoll 
	static const inline FRotator LookFromX = FRotator(0,180,0);
	static const inline FRotator LookFromY = FRotator(0,-90,0);
	static const inline FRotator LookFromZ = FRotator(-90,-90,0);
	static const inline FRotator LookToX = FRotator(0,0,0);
	static const inline FRotator LookToY = FRotator(0,90,0);
	static const inline FRotator LookToZ = FRotator(90,90,0);

	//基于系统的DPI, 保存缩放倍数
	static inline float ScaleBasedDPI = 1.f;
	static inline FVector2f LocalOffsetToCenter = FVector2f(AxisLength*2);
	static inline float LocalRange = 100.f;

	//虽然editor和runtime获取的并非同一camera旋转， 但由于二者不同时存在，固维护一个旋转变量即可
	//editor时， 由编辑器激活视口设置， 运行时，由玩家摄像机设置
	//值得注意的是，当editor时在UI面板查看，由于一定不会有玩家摄像机， UI面板中的实例不会主动设置该ViewRotation
	//使其旋转与编辑器视口一致， 这是比较好的效果
	static inline FRotator ViewRotation = FRotator::ZeroRotator;
	
	SLATE_BEGIN_ARGS(SNavigationManager) {}

	SLATE_END_ARGS()
	
	void Construct(const FArguments& InArgs);

	void CreateNavigationElements();

	virtual int32 OnPaint( const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const override;

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	
	FOverlaySlot* MakeNavigationElement(FSlateBrush* InBrush, const FVector& AxisDirection, const FColor AxisColor, const FString& ShowText, ENavigationPart PartIdentifier, const bool IsPositive);

	void ResetTickTimes()
	{
		TickTimes = 0;
		ViewStateIsInChanging = true;
	}
protected:
	virtual void UpdateViewRotation() const = 0;

	virtual void AutoGetDPIScaling() = 0;

	//virtual void UpdateDPIScaling(const float DPIScaling) = 0;

	void UpdateOffsetValue();
	
	void UpdateDepthSort();
	
	//mutable ELevelViewportType LastTimeLevelViewportType = LVT_None;
	//计tick次数, 前3次需执行特殊操作
	uint8 TickTimes = 0;
	
	mutable bool ViewStateIsInChanging = true;
	//子元素即用于渲染各轴向的widget
	TArray<TSharedPtr<SDirectionIndicatorWidget>> NavigationElements;
	
	//各子元素的slot, 排序设置zorder
	TArray<FOverlaySlot*> AxisSlots;
	
	//保存SortDepth为成员变量, 排序时基于深度排列FOverlaySlot
	TArray<TPair<float,FOverlaySlot*>> SortDepth;

public:
	FInputRayHit IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos);
	
	void UpdateHoverState(bool bHovering, uint32 PartIdentifier);
};
