﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "SNavigationGame.h"

#include "InteractiveNavigationUtils.h"
//#include "LevelEditor.h"
#include "Kismet/GameplayStatics.h"
//#include "IAssetViewport.h"
#include "Blueprint/WidgetLayoutLibrary.h"

void SNavigationGame::Construct(const FArguments& InArgs)
{
	OnBeginHovered = InArgs._OnBeginHovered;
	OnEndHovered = InArgs._OnEndHovered;
	OnHovering = InArgs._OnHovering;

	OnClicked = InArgs._OnClicked;
	OnDoubleClick = InArgs._OnDoubleClick;

	OnBeginDrag = InArgs._OnBeginDrag;
	OnDragging = InArgs._OnDragging;
	OnEndDrag = InArgs._OnEndDrag;
	
	if(PlayerController == nullptr)
	{
		PlayerController = UGameplayStatics::GetPlayerController(GWorld->GetWorld(),0);
	}
	if(PlayerController != nullptr)
	{
		
		PlayerController->GetViewportSize(ViewSizeX, ViewSizeY);
		ViewSizeX -= 2;
		ViewSizeY -= 2;
	}
	
	AutoGetDPIScaling();
	
	CreateNavigationElements();
}

void SNavigationGame::UpdateViewRotation() const
{
	if(PlayerController == nullptr) return;
	
	ViewStateIsInChanging = !ViewRotation.Equals(PlayerController->PlayerCameraManager->GetCameraRotation());
	if(ViewStateIsInChanging)
	{
		ViewRotation = PlayerController->PlayerCameraManager->GetCameraRotation();
	}
}

void SNavigationGame::AutoGetDPIScaling()
{
	//Runtime的Widget缩放，不受windows设置影响，无论Windows的DPI为多少，都不影响运行时缩放，而受设置影响，在设置不变的情况下啊，受窗口缩放影响,项目设置改为自定义，直接定义缩放比例
	
	if(PlayerController == nullptr) return;
	
	if(const float NewDPIScale = UWidgetLayoutLibrary::GetViewportScale(PlayerController);
		ScaleBasedDPI != NewDPIScale)
	{
		ScaleBasedDPI = NewDPIScale;
		UpdateOffsetValue();
	}
}

FReply SNavigationGame::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	//第一次点下触发
	if (LastHitPart != ETransformGizmoPartIdentifier::Default)
	{
		bIsMouseButtonDownPartForDrag = true;
		bIsMouseButtonDownPartForClicked = true;
		OnButtonDownPartMouseEvent = MouseEvent;
	}
	return SNavigationManager::OnMouseButtonDown(MyGeometry, MouseEvent);
}

FReply SNavigationGame::OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent)
{
	//第二次点下触发, 不限制按键，返回按键由用户筛选
	if (IsEnabled())
	{
		if (LastHitPart != ETransformGizmoPartIdentifier::Default)
		{
			OnDoubleClick.ExecuteIfBound(ConvertToENavigationPart(LastHitPart),InMouseEvent);
		}
	}
	
	return SNavigationManager::OnMouseButtonDoubleClick(InMyGeometry, InMouseEvent);
}

FReply SNavigationGame::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	HandleHoverEventOnMove(MouseEvent);
	
	return SNavigationManager::OnMouseMove(MyGeometry, MouseEvent);
}

void SNavigationGame::OnMouseEnter(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	//进入以及第一次松开时触发
	bIsMouseEnter = true;
	
	HandleClickedEvent(MouseEvent);
	
	SNavigationManager::OnMouseEnter(MyGeometry, MouseEvent);
}

void SNavigationGame::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	//离开以及第一次按下时触发
	bIsMouseEnter = false;
	SNavigationManager::OnMouseLeave(MouseEvent);
}

void SNavigationGame::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//即使鼠标没有聚焦也会执行，必须用它处理某些情况
	//鼠标按下，OnMove停止执行，所以需要tick检测
	if(PlayerController != nullptr)
	{
		HandleHoverEventOnTick();
		HandleBeginDragEvent();
		HandleDraggingAndEndEvent();

		if(bAutoUpdateDPIScaling)
		{
			AutoGetDPIScaling();
		}
	}
	
	SNavigationManager::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
}

FVector2D SNavigationGame::ComputeDesiredSize(float X) const
{
	//该widget的尺寸
	return DesiredSize;
}

void SNavigationGame::HandleClickedEvent(const FPointerEvent& MouseEvent)
{
	FInputRayHit RayHit = IsHit(MouseEvent.GetScreenSpacePosition());
	ETransformGizmoPartIdentifier HitPart;
	if(RayHit.bHit) 
	{
		HitPart = static_cast<ETransformGizmoPartIdentifier>(RayHit.HitIdentifier);
	}
	else
	{
		HitPart = ETransformGizmoPartIdentifier::Default;
	}

	//松开时在part， 按下时在part， 未移动，
	if(bIsMouseButtonDownPartForClicked)
	{
		if(HitPart != ETransformGizmoPartIdentifier::Default && !bIsOnDragging)
		{
			OnClicked.ExecuteIfBound(ConvertToENavigationPart(HitPart),MouseEvent);
		}
		bIsMouseButtonDownPartForClicked = false;
	}
}

void SNavigationGame::HandleHoverEventOnMove(const FPointerEvent& MouseEvent)
{
	//悬停时持续触发,悬停范围为边界返回，限制检测范围为导航UI
	FInputRayHit RayHit = IsHit(MouseEvent.GetScreenSpacePosition());
	
	ETransformGizmoPartIdentifier HitPart;

	//先记录是否执行，最后按顺序执行
	bool bExecuteOnBeginHovered = false;
	bool bExecuteOnHovering = false;
	bool bExecuteOnEndHovered = false;
	
	bool bUpdateLastHitPart = false;
	
	if(RayHit.bHit) 
	{
		HitPart = static_cast<ETransformGizmoPartIdentifier>(RayHit.HitIdentifier);
		//持续执行OnHovering回调，用户绑定，这里直接执行回调将导致OnHovering比OnBeginHovered执行的更早，固改为这种方式
		bExecuteOnHovering = true;
	}
	else
	{
		HitPart = ETransformGizmoPartIdentifier::Default;
	}
	if (HitPart != LastHitPart)
	{
		/*当前HitPart与上一帧不同，且不是空（Default），即进入新悬停*/
		if(HitPart != ETransformGizmoPartIdentifier::Default)
		{
			//执行一次这将执行一次OnBeginHover回调，用户绑定
			bExecuteOnBeginHovered = true;
			/*设置悬停样式，高亮文字*/
			UpdateHoverState(true,static_cast<uint32>(HitPart));
		}
		//如果LastHitPart不为空（default）, 且最新的HitPart不同, 说明此时是LastHitPart结束悬停的瞬间,设置LastHitPart悬停为false
		if (LastHitPart != ETransformGizmoPartIdentifier::Default)
		{
			//执行一次这将执行一次OnEndHover回调，用户绑定
			bExecuteOnEndHovered = true;
			/*设置悬停样式，恢复文字*/
			UpdateHoverState(false,static_cast<uint32>(LastHitPart));
		}
		bUpdateLastHitPart = true;
	}

	//调整顺序执行回调
	if(bExecuteOnBeginHovered)
	{
		OnBeginHovered.ExecuteIfBound(ConvertToENavigationPart(HitPart));
	}
	if(bExecuteOnHovering)
	{
		OnHovering.ExecuteIfBound(ConvertToENavigationPart(HitPart));
	}
	if(bExecuteOnEndHovered)
	{
		OnEndHovered.ExecuteIfBound(ConvertToENavigationPart(LastHitPart));
	}
	
	//这个也要往后调，否则执行OnEndHovered时LastHitPart已经更新为newPart了
	if(bUpdateLastHitPart)
	{
		LastHitPart = HitPart;
	}
}

void SNavigationGame::HandleHoverEventOnTick()
{
	/*在调用前已检查过PlayerController，但为避免该函数以后用在其他地方， 在此处检查*/
	if(PlayerController == nullptr) return;
	//鼠标不在NAV范围，开始使用tick检测
	if(!bIsMouseEnter)
	{
		//所有鼠标按键松开，按住时不更新
		if( !PlayerController->IsInputKeyDown(EKeys::LeftMouseButton) &&
			!PlayerController->IsInputKeyDown(EKeys::RightMouseButton) &&
			!PlayerController->IsInputKeyDown(EKeys::MiddleMouseButton))
		{
			//离开前是点中Part的
			if(LastHitPart != ETransformGizmoPartIdentifier::Default)
			{
				//更新其状态，恢复LastHitPart为空
				UpdateHoverState(false,static_cast<uint32>(LastHitPart));
				LastHitPart = ETransformGizmoPartIdentifier::Default;
			}
		}
	}
}

void SNavigationGame::HandleBeginDragEvent()
{
	/*在调用前已检查过PlayerController，但为避免该函数以后用在其他地方， 在此处检查*/
	if(PlayerController == nullptr) return;
	
	if(bIsMouseButtonDownPartForDrag)
	{
		IsLastMousePositionInitialized = false;
		if(!IsLastMousePositionInitialized)
		{
			PlayerController->GetMousePosition(LastMousePosition.X,LastMousePosition.Y);
			IsLastMousePositionInitialized = true;
		}
		bIsMouseButtonDownPartForDrag = false;
	}

	if(IsLastMousePositionInitialized == true)
	{
		FVector2D MousePosition;
		PlayerController->GetMousePosition(MousePosition.X,MousePosition.Y);
		
		if(FVector2D::DistSquared(MousePosition,LastMousePosition) > .1f)
		{
			if(PlayerController->IsInputKeyDown(OnButtonDownPartMouseEvent.GetEffectingButton()) && !bIsOnDragging)
			{
				OnBeginDrag.ExecuteIfBound(ConvertToENavigationPart(LastHitPart),OnButtonDownPartMouseEvent,LastMousePosition);
				bIsOnDragging = true;
				IsLastMousePositionInitialized = false;

				/*鼠标边界跳跃,开始drag时记录边界,-2为测试最边缘时鼠标位置值小2*/
				PlayerController->GetViewportSize(ViewSizeX, ViewSizeY);
				ViewSizeX -= 2;
				ViewSizeY -= 2;
			}
		}
	}
}

void SNavigationGame::HandleDraggingAndEndEvent()
{
	/*在调用前已检查过PlayerController，但为避免该函数以后用在其他地方， 在此处检查*/
	if(PlayerController == nullptr) return;
	
	if(bIsOnDragging)
	{
		//static FVector2D LocalLastMousePosition;
		FVector2D MousePosition;
		PlayerController->GetMousePosition(MousePosition.X,MousePosition.Y);
		
		if(!bJustJumped)
		{
			OnDragging.ExecuteIfBound(MousePosition-LastMousePosition);
		}
		/*鼠标边界跳跃 , 前后顺序不能变， 这个函数算出的bJustJumped掌管下一帧是否执行回调，可确保不输出跳跃值*/
		if(bJumpMouseAtViewportEdges)
		{
			JumpMouseAtViewportEdges(MousePosition);
		}
		
		LastMousePosition = MousePosition;
		
		if(!PlayerController->IsInputKeyDown(OnButtonDownPartMouseEvent.GetEffectingButton()))
		{
			bIsOnDragging = false;
			
			OnEndDrag.ExecuteIfBound(MousePosition);
		}
	}
}

ENavigationPart SNavigationGame::ConvertToENavigationPart(const ETransformGizmoPartIdentifier Identifier)
{
	switch (Identifier)
	{
		case ETransformGizmoPartIdentifier::Default:
			return ENavigationPart::Default;
		case ETransformGizmoPartIdentifier::TranslateXAxis:
			return ENavigationPart::PositiveX;
		case ETransformGizmoPartIdentifier::TranslateYAxis:
			return ENavigationPart::PositiveY;
		case ETransformGizmoPartIdentifier::TranslateZAxis:
			return ENavigationPart::PositiveZ;
		case ETransformGizmoPartIdentifier::RotateXAxis:
			return ENavigationPart::NegativeX;
		case ETransformGizmoPartIdentifier::RotateYAxis:
			return ENavigationPart::NegativeY;
		case ETransformGizmoPartIdentifier::RotateZAxis:
			return ENavigationPart::NegativeZ;
		default:
			return ENavigationPart::Default;
	}
}

void SNavigationGame::JumpMouseAtViewportEdges(const FVector2D& MousePosition)
{
	if(!bJustJumped)
	{
		if(MousePosition.X == 1 && LastMousePosition.X == 1)
		{
			PlayerController->SetMouseLocation(ViewSizeX,MousePosition.Y);
			bJustJumped = true;
		}
		if(ViewSizeX - MousePosition.X < 2/*容差*/ && ViewSizeX - LastMousePosition.X < 2)
		{
			PlayerController->SetMouseLocation(1,MousePosition.Y);
			bJustJumped = true;
		}
		if(MousePosition.Y == 1 && LastMousePosition.Y == 1)
		{
			PlayerController->SetMouseLocation(MousePosition.X,ViewSizeY);
			bJustJumped = true;
		}
		if(ViewSizeY - MousePosition.Y < 2 && ViewSizeY - LastMousePosition.Y < 2)
		{
			PlayerController->SetMouseLocation(MousePosition.X,1);
			bJustJumped = true;
		}
	}

	if(MousePosition != LastMousePosition)
	{
		if(MousePosition.X == LastMousePosition.X && abs(MousePosition.Y - LastMousePosition.Y) == ViewSizeY - 1) return;
		if(MousePosition.Y == LastMousePosition.Y && abs(MousePosition.X - LastMousePosition.X) == ViewSizeX - 1) return;
		bJustJumped = false;
	}
}