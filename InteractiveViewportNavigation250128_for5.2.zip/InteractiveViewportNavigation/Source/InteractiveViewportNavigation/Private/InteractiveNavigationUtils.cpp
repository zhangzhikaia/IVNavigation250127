﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "InteractiveNavigationUtils.h"

namespace IVNGlobalVariables
{
	static bool IsInPIE;

    static bool IsIVNEnable;
}

void InteractiveNavigationUtils::SetIsInPIE(const bool bIsInPIE)
{
    IVNGlobalVariables::IsInPIE = bIsInPIE;
}

bool InteractiveNavigationUtils::GetIsInPIEOrGame()
{
    return IVNGlobalVariables::IsInPIE || !GIsEditor;
}

void InteractiveNavigationUtils::SetIsIVNEnable(const bool bIsEnable)
{
    IVNGlobalVariables::IsIVNEnable = bIsEnable;
}

bool InteractiveNavigationUtils::GetIsIVNEnable()
{
    return IVNGlobalVariables::IsIVNEnable;
}