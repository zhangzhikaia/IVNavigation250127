﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "SNavigationManager.h"
#include "InteractiveNavigationUtils.h"
#include "SDirectionIndicatorWidget.h"
#include "Slate/SlateBrushAsset.h"
#include "Widgets/Layout/SScaleBox.h"
#include "VectorTypes.h"
//#include "EditorGizmos/TransformGizmo.h"

void SNavigationManager::Construct(const FArguments& InArgs)
{
}

void SNavigationManager::CreateNavigationElements()
{
	USlateBrushAsset* SlateBrushPositive = LoadObject<USlateBrushAsset>(nullptr, TEXT("/InteractiveViewportNavigation/SB_SpherePositive"));
	FSlateBrush* BrushPositive = SlateBrushPositive!=nullptr ? &SlateBrushPositive->Brush : new FSlateBrush();
	
	USlateBrushAsset* SlateBrushNegative = LoadObject<USlateBrushAsset>(nullptr, TEXT("/InteractiveViewportNavigation/SB_SphereNegative"));
	FSlateBrush* BrushNegative = SlateBrushNegative!=nullptr ? &SlateBrushNegative->Brush : new FSlateBrush();
	
	AxisSlots.SetNumUninitialized(ElementsNum);
	
	FOverlaySlot* SlotAxisX = MakeNavigationElement(
		BrushPositive,
		FVector(1.f,0.f,0.f),
		DIAxisColorX,
		FString(TEXT("X")),
		ENavigationPart::PositiveX,
		true
	);
	AxisSlots[0] = SlotAxisX;
	
	FOverlaySlot* SlotAxisY = MakeNavigationElement(
		BrushPositive,
		FVector(0.f,1.f,0.f),
		DIAxisColorY,
		FString(TEXT("Y")),
		ENavigationPart::PositiveY,
		true
	);
	AxisSlots[1] = SlotAxisY;
	
	FOverlaySlot* SlotAxisZ = MakeNavigationElement(
		BrushPositive,
		FVector(0.f,0.f,1.f),
		DIAxisColorZ,
		FString(TEXT("Z")),
		ENavigationPart::PositiveZ,
		true
	);
	AxisSlots[2] = SlotAxisZ;
	
	FOverlaySlot* SlotAxis_X = MakeNavigationElement(
		BrushNegative,
		FVector(-1.f,0.f,0.f),
		DIAxisColorX,
		FString(TEXT("-X")),
		ENavigationPart::NegativeX,
		false
	);
	AxisSlots[3] = SlotAxis_X;
	
	FOverlaySlot* SlotAxis_Y = MakeNavigationElement(
		BrushNegative,
		FVector(0.f,-1.f,0.f),
		DIAxisColorY,
		FString(TEXT("-Y")),
		ENavigationPart::NegativeY,
		false
	);
	AxisSlots[4] = SlotAxis_Y;
	
	FOverlaySlot* SlotAxis_Z = MakeNavigationElement(
		BrushNegative,
		FVector(0.f,0.f,-1.f),
		DIAxisColorZ,
		FString(TEXT("-Z")),
		ENavigationPart::NegativeZ,
		false
	);
	AxisSlots[5] = SlotAxis_Z;
	
	//以0元素初始化, 避免出现未初始化的值
	SortDepth.SetNumZeroed(ElementsNum);

	//初始化tick计数
	ResetTickTimes();
	
	SetCanTick(true);
}

int32 SNavigationManager::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId,const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	UpdateViewRotation();

	//遍历子项, 调用子项的OnPaint(), 
	return SOverlay::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle,bParentEnabled);
}

void SNavigationManager::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	//第1帧, 此时排序开始有效,强制排序一次,无论视口是否变化.
	if(TickTimes == 1)
	{
		UpdateDepthSort();
	}
	//第2帧, 开始tick检查视口是否变化, 若变化, 执行排序,并更新视口信息
	if(TickTimes > 1 && ViewStateIsInChanging)
	{
		UpdateDepthSort();
	}

	//每帧计数加1, 在第1帧将计数加到2后就不再执行计数
	if(TickTimes < 2) { ++TickTimes; }
	
	SOverlay::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
}

::SOverlay::FOverlaySlot* SNavigationManager::MakeNavigationElement(FSlateBrush* InBrush, const FVector& AxisDirection, const FColor AxisColor, const FString& ShowText, ENavigationPart PartIdentifier, const bool IsPositive)
{
	TSharedPtr<SDirectionIndicatorWidget> NavigationElement;
	FOverlaySlot* SlotAxisZ = AddSlot()
	[
		SNew(SScaleBox)
		.Stretch(EStretch::ScaleToFit)
		.HAlign(HAlign_Right)
		[
			//DirectionIndicator.ToSharedRef()
			SAssignNew(NavigationElement,SDirectionIndicatorWidget)
			.SetBrush(InBrush)
			//.SetEditorViewportClient(EditorViewportClient)
			.SetAxisDirection(AxisDirection * AxisLength)
			.SetAxisColor(FLinearColor::FromPow22Color(AxisColor))
			.SetAxisText(ShowText)
			.SetPartIdentifier(static_cast<uint32>(PartIdentifier))
			.SetIsPositive(IsPositive)
		]
	].GetSlot();
	NavigationElements.Add(NavigationElement);
	return SlotAxisZ;
}

void SNavigationManager::UpdateOffsetValue()
{
	LocalOffsetToCenter = OffsetToCenter * ScaleBasedDPI;
	LocalRange = 100.f * ScaleBasedDPI * ScaleBasedDPI;
}

void SNavigationManager::UpdateDepthSort()
{
	//按深度排序
	for (int i = 0; i < ElementsNum; ++i)
	{
		SortDepth[i] = TPair<float,FOverlaySlot*>(NavigationElements[i]->GetLoaclDepth(),AxisSlots[i]);
	}
	
	SortDepth.Sort();
	
	for(int i = 0; i < ElementsNum; ++i)
	{
		SortDepth[i].Value->SetZOrder(ElementsNum-i);
	}
}

FInputRayHit SNavigationManager::IsHit(const UE::Slate::FDeprecateVector2DResult& MouseScreenPos)
{
	FInputRayHit Hit;
	for(TSharedPtr<SDirectionIndicatorWidget> Current : NavigationElements)
	{
		if(Current.IsValid())
		{
			//todo:这里需要检查所有, 找到最前的
			const FInputRayHit NewHit = Current->IsHit(MouseScreenPos);
			if ((!Hit.bHit || NewHit.HitDepth < Hit.HitDepth) && NewHit.bHit)
			{
				Hit = NewHit;
			}
		}
	}
	
	return Hit;
}

void SNavigationManager::UpdateHoverState(bool bHovering, uint32 PartIdentifier)
{
	for(TSharedPtr<SDirectionIndicatorWidget> Current : NavigationElements)
	{
		if(Current.IsValid())
		{
			Current->UpdateHoverState(bHovering,PartIdentifier);
		}
	}
}