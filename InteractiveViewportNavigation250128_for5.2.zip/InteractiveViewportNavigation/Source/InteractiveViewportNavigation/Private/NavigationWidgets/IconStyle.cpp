﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#include "IconStyle.h"

#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyleMacros.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/StyleColors.h"
#include "Styling/SlateStyle.h"
#include "Styling/SlateTypes.h"


/*IMAGE_BRUSH macro dependent*/
#define RootToContentDir CustomStyleSet->RootToContentDir

/*class FIconStyle*/
TSharedPtr<FSlateStyleSet> FIconStyle::CreatedSlateStyleSet = nullptr;

void FIconStyle::InitializeIcons()
{
	if(!CreatedSlateStyleSet.IsValid())
	{
		CreatedSlateStyleSet = CreateSlateStyleSet();
		FSlateStyleRegistry::RegisterSlateStyle(*CreatedSlateStyleSet);
	}
}

void FIconStyle::ShutDownIcons()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*CreatedSlateStyleSet);
	ensure(CreatedSlateStyleSet.IsUnique());
	CreatedSlateStyleSet.Reset();
}

/*void FIconStyle::RefreshSet(/*TArray<FString> AddFiles#1#)
{
	ShutDownIcons();
	InitializeIcons();
}*/

const ISlateStyle& FIconStyle::Get()
{
	return *CreatedSlateStyleSet;
}

FName FIconStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("DIIconStyle"));
	return StyleSetName;
}

TSharedRef<FSlateStyleSet> FIconStyle::CreateSlateStyleSet()
{
	TSharedRef<FSlateStyleSet> CustomStyleSet = MakeShareable(new FSlateStyleSet(GetStyleSetName()));
	
	const FString IconDirectory = IPluginManager::Get().FindPlugin(TEXT("InteractiveViewportNavigation"))->GetBaseDir() /"Resources";
	
	//const FString ShortcutDirectory = FAUtilities::GetShortcutsDirectory();
	/*IMAGE_BRUSH macro dependent*/
	CustomStyleSet->SetContentRoot(IconDirectory); 
	
	const FVector2D Icon64X64(64.f,64.f);
	
	const FCheckBoxStyle CheckBoxStyle = FCheckBoxStyle()
	.SetCheckBoxType(ESlateCheckBoxType::ToggleButton)
	.SetPadding(FMargin(10.f))
	/*设置未勾选状态三种样式*/
	.SetUncheckedImage(IMAGE_BRUSH("Icon128",Icon64X64,FStyleColors::White25))
	.SetUncheckedHoveredImage(IMAGE_BRUSH("Icon128",Icon64X64,FStyleColors::Foreground))
	.SetUncheckedPressedImage(IMAGE_BRUSH("Icon128",Icon64X64,FStyleColors::AccentBlack))
	/*设置勾选状态三种样式*/
	.SetCheckedImage(IMAGE_BRUSH("Icon128",Icon64X64,FStyleColors::Foreground))
	.SetCheckedHoveredImage(IMAGE_BRUSH("Icon128",Icon64X64,FStyleColors::White25))
	.SetCheckedPressedImage(IMAGE_BRUSH("Icon128",Icon64X64,FStyleColors::Background));
	
	
	CustomStyleSet->Set("BoxStyle",CheckBoxStyle);
	
	return CustomStyleSet;
}

#undef RootToContentDir