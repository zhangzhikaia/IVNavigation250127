// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

using UnrealBuildTool;

public class InteractiveViewportNavigation : ModuleRules
{
	public InteractiveViewportNavigation(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		//PrecompileForTargets = PrecompileTargetsType.Any;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"Projects",
				"UMG",
				"ApplicationCore",
				"DeveloperSettings",
				// ... add other public dependencies that you statically link with here ...
				
			}
			);
		
		
		if (Target.Type == TargetRules.TargetType.Editor)
		{
			PublicDependencyModuleNames.AddRange(
				new string[]
				{
					//
				}
			);
			PrivateDependencyModuleNames.AddRange(
				new string[]
				{
					"UnrealEd",
					"LevelEditor",
					"EditorInteractiveToolsFramework",
				}
			);
		}
		

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				"InputCore",
				"InteractiveToolsFramework",
				// ... add private dependencies that you statically link with here ...	
				
				//带上这个很多内容没有索引头文件也不报错， 但打包editorframework失败， 不带这个编译不报错， 打包识别不了内容， 把所有缺少头文件 的手动补充
				//"EditorFramework",
				
			}
			);
		
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
	}
}
