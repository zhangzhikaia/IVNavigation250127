﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once

class ISlateStyle;

class FIconStyle
{
public:

	static void InitializeIcons(); 

	static void ShutDownIcons();

	//static void RefreshSet();

	static const ISlateStyle& Get();

	static FName GetStyleSetName();

private:
	
	static TSharedRef<FSlateStyleSet> CreateSlateStyleSet();
	
	static TSharedPtr<FSlateStyleSet> CreatedSlateStyleSet;
};