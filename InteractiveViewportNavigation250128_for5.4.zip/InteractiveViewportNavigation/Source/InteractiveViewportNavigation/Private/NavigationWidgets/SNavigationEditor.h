﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once

//#include "EditorViewportClient.h"
#include "InteractiveNavigationUtils.h"
#if SWITCH_WITH_EDITOR

#include "SNavigationManager.h"

class SNavigationEditor : public SNavigationManager
{
public:
	
	SLATE_BEGIN_ARGS(SNavigationEditor) {}

	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	virtual FVector2D ComputeDesiredSize(float) const override;
	
	//virtual int32 OnPaint( const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const override;

	virtual void UpdateViewRotation() const override;

	virtual void AutoGetDPIScaling() override;

	bool UpdateNavigationNeedFixState() const;

private:
	FEditorViewportClient* EditorViewportClient = nullptr;

public:
	FDelegateHandle OnPostEditChangePropertyAutoGetDPIScaling;
};

#endif