﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.
#pragma once


#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"

#include "InteractiveNavigationSettings.generated.h"

UENUM()
enum class EDisplayDeviceScaling : uint8
{
	DPI_100 UMETA(DisplayName="100%"),
	DPI_125 UMETA(DisplayName="125%"),
	DPI_150 UMETA(DisplayName="150%"),
	DPI_175 UMETA(DisplayName="175%"),
	DPI_200 UMETA(DisplayName="200%"),
};

UENUM()
enum class ESwitchModeOnClickAxis : uint8
{
	MaintainCurrent UMETA(DisplayName="MaintainCurrent"),
	Orthographic UMETA(DisplayName="ToOrthographic"),
	Perspective UMETA(DisplayName="ToPerspective"),
};

struct FNavigationSettingsDelegates
{
	DECLARE_MULTICAST_DELEGATE/*_OneParam*/(FOnPostEditChangeProperty/*, const class UInteractiveNavigationSettings**/);
	//FOnPostEditChangeProperty& GetOnPostEditChangeProperty() {return OnPostEditChangeProperty;}
	
	static FOnPostEditChangeProperty OnPostEditChangeProperty;
};

UCLASS(config = Engine, defaultconfig)
class UInteractiveNavigationSettings : public UDeveloperSettings
{
public:
	GENERATED_BODY()
	
	UInteractiveNavigationSettings();

	//~ Begin UDeveloperSettings interface
	//大分类, 若不存在新建分类
	virtual FName GetCategoryName() const override;
#if WITH_EDITOR
	//大类下二级分类, 一般为插件名
	virtual FText GetSectionText() const override;
	virtual FName GetSectionName() const override;
	virtual FText GetSectionDescription() const override;

	//~ End UDeveloperSettings interface
	
	/** UObject interface */
	//任何属性值修改将调用
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;

#endif
	
	UPROPERTY(config, EditAnywhere, Category = "Calibration", DisplayName = "Manual",meta = (ToolTip="If checked, you will manually specify the scaling value for the current display device.",ConfigRestartRequired = false))
	bool bManualCorrectDeviation = false;

	UPROPERTY(config, EditAnywhere, Category = "Calibration", DisplayName = "Scaling", meta = (ToolTip="Please check windows setting: Display Settings - Scale and Layout (Change the size of text, apps, and other items.",EditCondition = "bManualCorrectDeviation"))
	EDisplayDeviceScaling DPI = EDisplayDeviceScaling::DPI_100;

	UPROPERTY(config, EditAnywhere, Category = "OnClickAnAxis", DisplayName = "ToggleViewMode",meta = (ToolTip="When clicking on an axis to switch the view direction, should it switch to an orthographic view or remain in perspective mode?",ConfigRestartRequired = false))
	ESwitchModeOnClickAxis SwitchMode = ESwitchModeOnClickAxis::Orthographic;

	
};
