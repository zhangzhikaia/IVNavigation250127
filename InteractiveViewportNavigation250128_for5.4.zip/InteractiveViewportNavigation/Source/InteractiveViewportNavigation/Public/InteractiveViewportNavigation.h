// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "NavigationWidgets/SNavigationGame.h"

#include "CoreMinimal.h"
#include "Components/Widget.h"
#include "InteractiveViewportNavigation.generated.h"

/**
 * 
 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FNavigationHoverEventMulti,const ENavigationPart,NavigationPart);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FNavigationClickEventMulti,const ENavigationPart,NavigationPart,const FPointerEvent&,MouseEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams( FNavigationBeginDragEventMulti, const ENavigationPart /*Part*/,NavigationPart,const FPointerEvent& /*MouseButton*/,MouseEvent, const FVector2D&,MousePosition);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam( FNavigationDraggingEventSimpleMulti, const FVector2D&,DeltaMousePosition);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam( FNavigationEndDragEventSimpleMulti, const FVector2D&,MousePosition);


UCLASS()
class INTERACTIVEVIEWPORTNAVIGATION_API UInteractiveViewportNavigation : public UWidget
{
	GENERATED_BODY()

public:
	//~ Begin UVisual Interface
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	//~ End UVisual Interface

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" )
	FNavigationHoverEventMulti OnBeginHovered;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" )
	FNavigationHoverEventMulti OnEndHovered;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" )
	FNavigationHoverEventMulti OnHovering;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" ,meta = (ToolTip="Double-click inevitably triggers a single-click event, please ensure that the events bound to the two do not interfere with each other."))
	FNavigationClickEventMulti OnClicked;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" ,meta = (ToolTip="Double-click inevitably triggers a single-click event, please ensure that the events bound to the two do not interfere with each other."))
	FNavigationClickEventMulti OnDoubleClick;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" )
	FNavigationBeginDragEventMulti OnBeginDrag;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" )
	FNavigationDraggingEventSimpleMulti OnDragging;

	UPROPERTY( BlueprintAssignable, Category = "InteractiveViewportNavigation|Event" )
	FNavigationEndDragEventSimpleMulti OnEndDrag;

	

	UFUNCTION( BlueprintCallable, Category = "InteractiveViewportNavigation|Settings" )
	void SetJumpMouseAtViewportEdgesOnDragging( const bool IfJumpMouseAtViewportEdges );

	/**
	 * @param bAfterAutoUpdate Enable subsequent automatic updates (true by default, but may incur performance costs, so you can disable it based on your needs).
	 */
	UFUNCTION( BlueprintCallable, Category = "InteractiveViewportNavigation|Settings" ,meta = (ToolTip="When the viewport size changes, if DPI scaling rules are set for the project, the navigation UI will scale accordingly, resulting in a deviation between the mouse click position and the display position. To address this, you can actively update the DPI scaling (by automatically obtaining the value)."))
	void UpdateDPIScaling( const bool bAfterAutoUpdate );

	
private:

	TSharedPtr<class SNavigationGame> MyNavigationGame;

protected:
	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	//~ End UWidget Interface

	void SlateHandleBeginHovered(const ENavigationPart NavigationPart);

	void SlateHandleEndHovered(const ENavigationPart NavigationPart);

	void SlateHandleOnHovering(const ENavigationPart NavigationPart);

	void SlateHandleOnClicked(const ENavigationPart NavigationPart,const FPointerEvent& MouseEvent);

	void SlateHandleOnDoubleClick(const ENavigationPart NavigationPart,const FPointerEvent& MouseEvent);

	void SlateHandleOnBeginDrag(const ENavigationPart NavigationPart,const FPointerEvent& MouseEvent,const FVector2D& MousePosition);

	void SlateHandleOnDragging(const FVector2D& DeltaMousePosition);

	void SlateHandleOnEndDrag(const FVector2D& MousePosition);
};
