﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "SNavigationManager.h"

class APlayerCameraManager;

UENUM(BlueprintType)
enum class ENavigationPart : uint8
{
	PositiveX UMETA(DisplayName="X"),
	PositiveY UMETA(DisplayName="Y"),
	PositiveZ UMETA(DisplayName="Z"),
	NegativeX UMETA(DisplayName="-X"),
	NegativeY UMETA(DisplayName="-Y"),
	NegativeZ UMETA(DisplayName="-Z"),
	Default UMETA(DisplayName="Empty"),
};

DECLARE_DELEGATE_OneParam( FNavigationHoverEvent, const ENavigationPart /*Part*/)
DECLARE_DELEGATE_TwoParams( FNavigationClickEvent, const ENavigationPart /*Part*/,const FPointerEvent& /*MouseButton*/)
DECLARE_DELEGATE_ThreeParams( FNavigationDragEvent, const ENavigationPart /*Part*/,const FPointerEvent& /*MouseButton*/, const FVector2D& /*MousePos*/)
DECLARE_DELEGATE_OneParam( FNavigationDragEventSimple, const FVector2D& /*MousePos*/)

//DECLARE_DELEGATE_OneParam( FOnEndHovered, const ENavigationPart /*Part*/)

class SNavigationGame : public SNavigationManager
{
public:
	SLATE_BEGIN_ARGS(SNavigationGame) {}

		SLATE_EVENT( FNavigationHoverEvent, OnBeginHovered )
		SLATE_EVENT( FNavigationHoverEvent, OnEndHovered )
		SLATE_EVENT( FNavigationHoverEvent, OnHovering )

		SLATE_EVENT( FNavigationClickEvent, OnClicked )
		SLATE_EVENT( FNavigationClickEvent, OnDoubleClick )
		
		SLATE_EVENT( FNavigationDragEvent, OnBeginDrag )
		SLATE_EVENT( FNavigationDragEventSimple, OnDragging )
		SLATE_EVENT( FNavigationDragEventSimple, OnEndDrag )
		
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	virtual void UpdateViewRotation() const override;

	virtual void AutoGetDPIScaling() override;

	//~ SWidget overrides
	virtual FReply OnMouseButtonDown( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent ) override;
	virtual FReply OnMouseButtonDoubleClick(const FGeometry& InMyGeometry, const FPointerEvent& InMouseEvent) override;
	/*virtual FReply OnMouseButtonUp( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent ) override;*/////第二次松开触发， 不使用
	virtual FReply OnMouseMove( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent ) override;
	virtual void OnMouseEnter( const FGeometry& MyGeometry, const FPointerEvent& MouseEvent ) override;
	virtual void OnMouseLeave( const FPointerEvent& MouseEvent ) override;

	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	virtual FVector2D ComputeDesiredSize(float) const override;
	//~ SWidget

	bool bJumpMouseAtViewportEdges = false;
	bool bJustJumped = false;
	bool bAutoUpdateDPIScaling = true;
private:
	/*function*/
	void HandleClickedEvent(const FPointerEvent& MouseEvent);
	
	void HandleHoverEventOnMove(const FPointerEvent& MouseEvent);

	void HandleHoverEventOnTick();

	void HandleBeginDragEvent();

	void HandleDraggingAndEndEvent();
	
	ENavigationPart ConvertToENavigationPart(const ETransformGizmoPartIdentifier Identifier);

	void JumpMouseAtViewportEdges(const FVector2D& MousePosition);
	
	/*properties*/
	//APlayerCameraManager* PlayerCameraManager = nullptr;
	APlayerController* PlayerController = nullptr;

	ETransformGizmoPartIdentifier LastHitPart = ETransformGizmoPartIdentifier::Default;

	FPointerEvent OnButtonDownPartMouseEvent;

	FVector2D LastMousePosition;

	bool bIsMouseButtonDownPartForDrag = false;

	bool bIsMouseButtonDownPartForClicked = false;

	bool bIsMouseEnter = false;

	bool IsLastMousePositionInitialized = false;

	bool bIsOnDragging = false;
	
	int32 ViewSizeX = 1920;
	int32 ViewSizeY = 1080;
	
	/*delegates*/
	FNavigationHoverEvent OnBeginHovered;
	FNavigationHoverEvent OnEndHovered;
	FNavigationHoverEvent OnHovering;

	FNavigationClickEvent OnClicked;
	FNavigationClickEvent OnDoubleClick;

	FNavigationDragEvent OnBeginDrag;
	FNavigationDragEventSimple OnDragging;
	FNavigationDragEventSimple OnEndDrag;
};
