// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "InteractiveViewportNavigation.h"

//#include "InteractiveNavigationUtils.h"
#include "NavigationWidgets/SNavigationGame.h"
//#include "NavigationWidgets/SNavigationEditor.h"

void UInteractiveViewportNavigation::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);

	MyNavigationGame.Reset();
}

void UInteractiveViewportNavigation::SetJumpMouseAtViewportEdgesOnDragging(const bool IfJumpMouseAtViewportEdges)
{
	if(MyNavigationGame.IsValid())
	{
		MyNavigationGame->bJumpMouseAtViewportEdges = IfJumpMouseAtViewportEdges;
		if(IfJumpMouseAtViewportEdges == false)
		{
			MyNavigationGame->bJustJumped = false;
		}
	}
}

void UInteractiveViewportNavigation::UpdateDPIScaling(const bool bAfterAutoUpdate)
{
	if(MyNavigationGame.IsValid())
	{
		MyNavigationGame->AutoGetDPIScaling();
		MyNavigationGame->bAutoUpdateDPIScaling = bAfterAutoUpdate;
	}
}

TSharedRef<SWidget> UInteractiveViewportNavigation::RebuildWidget()
{
PRAGMA_DISABLE_DEPRECATION_WARNINGS
	MyNavigationGame = SNew(SNavigationGame)
		.OnBeginHovered_UObject( this, &ThisClass::SlateHandleBeginHovered )
		.OnEndHovered_UObject( this, &ThisClass::SlateHandleEndHovered )
		.OnHovering_UObject( this, &ThisClass::SlateHandleOnHovering )
		.OnClicked_UObject( this, &ThisClass::SlateHandleOnClicked )
		.OnDoubleClick_UObject( this, &ThisClass::SlateHandleOnDoubleClick )
		.OnBeginDrag_UObject( this, &ThisClass::SlateHandleOnBeginDrag )
		.OnDragging_UObject( this, &ThisClass::SlateHandleOnDragging )
		.OnEndDrag_UObject( this, &ThisClass::SlateHandleOnEndDrag );
PRAGMA_ENABLE_DEPRECATION_WARNINGS
		//SLATE_EVENT(FOnUserScrolled, OnUserScrolled)

	return MyNavigationGame.ToSharedRef();
}

void UInteractiveViewportNavigation::SlateHandleBeginHovered(const ENavigationPart NavigationPart)
{
	OnBeginHovered.Broadcast(NavigationPart);
	//BroadcastBinaryPostStateChange(UWidgetHoveredStateRegistration::Bit, true);
}

void UInteractiveViewportNavigation::SlateHandleEndHovered(const ENavigationPart NavigationPart)
{
	OnEndHovered.Broadcast(NavigationPart);
}

void UInteractiveViewportNavigation::SlateHandleOnHovering(const ENavigationPart NavigationPart)
{
	OnHovering.Broadcast(NavigationPart);
}

void UInteractiveViewportNavigation::SlateHandleOnClicked(const ENavigationPart NavigationPart,const FPointerEvent& MouseEvent)
{
	OnClicked.Broadcast(NavigationPart,MouseEvent);
}

void UInteractiveViewportNavigation::SlateHandleOnDoubleClick(const ENavigationPart NavigationPart,const FPointerEvent& MouseEvent)
{
	OnDoubleClick.Broadcast(NavigationPart,MouseEvent);
}

void UInteractiveViewportNavigation::SlateHandleOnBeginDrag(const ENavigationPart NavigationPart,const FPointerEvent& MouseEvent, const FVector2D& MousePosition)
{
	OnBeginDrag.Broadcast(NavigationPart,MouseEvent,MousePosition);
}

void UInteractiveViewportNavigation::SlateHandleOnDragging(const FVector2D& DeltaMousePosition)
{
	OnDragging.Broadcast(DeltaMousePosition);
}

void UInteractiveViewportNavigation::SlateHandleOnEndDrag(const FVector2D& MousePosition)
{
	OnEndDrag.Broadcast(MousePosition);
}